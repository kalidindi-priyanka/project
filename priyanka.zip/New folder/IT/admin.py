from django.contrib import admin

# Register your models here.
from IT.models import Student
admin.site.register(Student)